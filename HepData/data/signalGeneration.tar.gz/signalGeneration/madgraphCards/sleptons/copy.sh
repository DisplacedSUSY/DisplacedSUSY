#!/bin/bash

default="sleptons"

for m in 50 100 200 300 400 500 600 700 800 900 1000 #selectrons and smuons
do
    echo Copying mass $m
    newdir="$default"_"$m"
    mkdir $newdir
    cp "$default"_param_card.dat $newdir/"$default"_"$m"_param_card.dat
    cp "$default"_proc_card.dat $newdir/"$default"_"$m"_proc_card.dat
    cp "$default"_run_card.dat $newdir/"$default"_"$m"_run_card.dat

    # modify output name
    sed -i 's/'$default'/'$default'_'$m'/g' $newdir/"$default"_"$m"_proc_card.dat
    # Modify mass parameter
    sed -i 's/MSLEP/'$m'.0/g' $newdir/"$default"_"$m"_param_card.dat
done

# ./gridpack_generation.sh BBAToZhToLLTT_4f_M300 cards/production/13TeV/BBAToZhToLLTT_4f_M300/ #1nd
