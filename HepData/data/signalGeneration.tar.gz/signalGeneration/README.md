# Instructions to create signal samples

### Stop signal

The Displaced SUSY stop signal is generated in pythia.

```pythia_DisplacedSUSY_stopToLB_M_XXX_YYYmm_TuneCP5_13TeV.cmnd``` is the pythia config file for the Displaced SUSY stop to lb signal. 
```pythia_DisplacedSUSY_stopToLD_M_XXX_YYYmm_TuneCP5_13TeV.cmnd``` is the pythia config file for the Displaced SUSY stop to ld signal. 
```DisplacedSUSY_stopToLB_M_XXX_YYYmm.slha``` is the SLHA file for the lb decay.
```DisplacedSUSY_stopToLD_M_XXX_YYYmm.slha``` is the SLHA file for the ld decay.

To produce all of the stop configs used in the analysis, run:
```
source createPoints_stops.csh
```

### GMSB slepton signal

The GMSB slepton signal is generated in madgraph and pythia, and then the decay is done in geant4. Thus, the sleptons and staus are set to be stable in madgraph and pythia.
We generate two sets of samples: "slepton" samples, which contain selectrons and smuons, and "stau" samples, which only produce staus.

**Gridpacks**
The madgraph gridpacks should be created first. We describe the procedure to create the slepton gridpacks below. The procedure for the "stau" samples is analogous.

To create the configs for the slepton gridpacks:
```
cd madgraphCards/sleptons
source copy.sh
```
This will produce the configs for all of the slepton mass points used in the analysis. This command uses the
```sleptons_param_card.dat``` file, which is the slepton madgraph parameter card,
```sleptons_proc_card.dat``` file, which is the slepton madgraph proc card, and
```sleptons_run_card.dat``` file, which is the slepton madgraph run card.

**Pythia**

```pythia_Sleptons_M_XXX_YYYmm_TuneCP5_13TeV.cmnd``` is the pythia config file for the slepton signal. 
```pythia_Staus_M_XXX_YYYmm_TuneCP5_13TeV.cmnd``` is the pythia config file for the stau signal. 
```Sleptons_M_XXX_YYYmm.slha``` is the SLHA file for the sleptons.
```Staus_M_XXX_YYYmm.slha``` is the SLHA file for the staus.

To produce all of the slepton/stau pythia configs used in the analysis, run:
```
source createPoints_sleptons.csh
source createPoints_staus.csh
```

**Geant**

The slepton/stau decay is done in geant4. 
The ```geant4_sleptons_XXX_YYYmm.txt``` and ```geant4_staus_XXX_YYYmm.txt``` files show how this is done.


### H to SS signal

The Higgs to SS signal is generated in powheg and pythia.

You can produce a H to SS config with a command like this:

```
python HiggsGeneration.py -n 50000 -H 125 -X 30 -T 10
```

This will produce 50000 events with mH = 125 GeV, mX = 30 GeV and ctau = 10 mm. See 

```
python HiggsGeneration.py --help
```
for more details.